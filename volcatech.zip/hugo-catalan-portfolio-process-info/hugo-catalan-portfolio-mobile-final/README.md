# Portfolio de Hugo Catalan

Portfolio profesional de desarrollo web con estética Dark Premium / Tech.

## Archivos

- `index.html`: estructura, contenido, SEO, navegación y enlaces de contacto.
- `styles.css`: identidad visual, layout, responsive, estados y animaciones.
- `script.js`: navegación suave, sección activa, menú móvil y animaciones de entrada.
- `robots.txt`: instrucciones básicas para buscadores.

## Contacto

- WhatsApp: enlace directo al número configurado en el proyecto.
- Gmail: `hugo.catalan.dev@gmail.com`.
- Instagram: reemplazar el enlace genérico por la URL definitiva del perfil.

## Nota

Los bloques principales de HTML, CSS y JavaScript incluyen comentarios explicativos para facilitar el mantenimiento y el aprendizaje.


## SEO antes de publicar
- El canonical usa `/`, por lo que se adapta automáticamente al dominio donde se publique.
- No se inventó un dominio ni una URL de sitemap. Cuando tengas el dominio definitivo, agregá la línea `Sitemap: https://tu-dominio.com/sitemap.xml` en `robots.txt` y creá el sitemap con esa URL.
- El enlace de Instagram queda intencionalmente en `https://www.instagram.com/` hasta que armes tu perfil.
