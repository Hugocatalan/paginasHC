// Referencias principales del DOM para controlar menú, navegación y secciones.
const body = document.body;
const collapseBtn = document.getElementById("collapseBtn");
const navLinks = document.querySelectorAll(".nav-link");
const sections = document.querySelectorAll("main section[id]");

// Alterna el menú lateral en escritorio y el menú desplegable en móvil.
collapseBtn.addEventListener("click", () => {
  if (window.innerWidth <= 760) {
    const open = body.classList.toggle("mobile-menu-open");
    document.getElementById("sidebar").classList.toggle("mobile-open", open);
    collapseBtn.setAttribute("aria-expanded", String(open));
    collapseBtn.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
    return;
  }
  const collapsed = body.classList.toggle("sidebar-collapsed");
  collapseBtn.setAttribute("aria-expanded", String(!collapsed));
  collapseBtn.setAttribute("aria-label", collapsed ? "Mostrar menú" : "Ocultar menú");
});

// Bloqueo temporal para evitar que el scroll cambie el botón activo durante un desplazamiento suave.
let navigationLock = false;
let navigationTimer;
let scrollTicking = false;

// Marca visualmente la sección actualmente seleccionada en el navbar.
function setActiveSection(sectionId) {
  navLinks.forEach(link => {
    const active = link.dataset.section === sectionId;
    link.classList.toggle("active", active);
    if (active) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
}

// Determina la sección activa usando una única línea de referencia para evitar saltos entre secciones.
function updateActiveFromScroll() {
  if (navigationLock) return;

  // Use one fixed reading line instead of IntersectionObserver. This avoids
  // two adjacent sections being considered active during smooth scrolling.
  const triggerY = Math.min(window.innerHeight * 0.38, 360);
  let current = sections[0]?.id;

  sections.forEach(section => {
    if (section.getBoundingClientRect().top <= triggerY) {
      current = section.id;
    }
  });

  if (current) setActiveSection(current);
}

// Gestiona los clics del navbar, el scroll suave y el cierre automático del menú móvil.
navLinks.forEach(link => {
  link.addEventListener("click", event => {
    const targetId = link.dataset.section;
    const target = document.getElementById(targetId);
    if (!target) return;

    event.preventDefault();
    navigationLock = true;
    clearTimeout(navigationTimer);
    setActiveSection(targetId);
    history.replaceState(null, "", `#${targetId}`);
    if (window.innerWidth <= 760) {
      body.classList.remove("mobile-menu-open");
      document.getElementById("sidebar").classList.remove("mobile-open");
      collapseBtn.setAttribute("aria-expanded", "false");
      collapseBtn.setAttribute("aria-label", "Abrir menú");
    }

    target.scrollIntoView({ behavior: "smooth", block: "start" });

    // Wait for the smooth scroll to settle, then let scroll position
    // determine the active section again.
    navigationTimer = setTimeout(() => {
      navigationLock = false;
      updateActiveFromScroll();
    }, 1100);
  });
});

// Actualiza el estado activo durante el scroll usando requestAnimationFrame para evitar trabajo excesivo.
window.addEventListener("scroll", () => {
  if (scrollTicking) return;
  scrollTicking = true;
  requestAnimationFrame(() => {
    updateActiveFromScroll();
    scrollTicking = false;
  });
}, { passive: true });

updateActiveFromScroll();

// Controla los botones +info de cada etapa del proceso y revela una explicación más profunda.
document.querySelectorAll(".process-more").forEach(button => {
  button.addEventListener("click", () => {
    const step = button.closest(".process-step");
    if (!step) return;

    const isOpen = step.classList.toggle("is-open");
    button.setAttribute("aria-expanded", String(isOpen));

    const detail = step.querySelector(".process-detail");
    if (detail) detail.setAttribute("aria-hidden", String(!isOpen));
  });
});

// Observa los elementos con clase .reveal para mostrarlos cuando entran en pantalla.
const revealObserver = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12 }
);

// Activa la observación de todas las piezas animadas del sitio.
document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));

// Mantiene el estado del menú coherente cuando cambia el tamaño de la ventana.
window.addEventListener("resize", () => {
  if (window.innerWidth <= 760) {
    body.classList.remove("sidebar-collapsed");
  } else {
    body.classList.remove("mobile-menu-open");
    document.getElementById("sidebar").classList.remove("mobile-open");
  }
});
